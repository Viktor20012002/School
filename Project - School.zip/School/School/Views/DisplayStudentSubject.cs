﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplayStudentSubject
    {
        private StudentSubjectController controller = new StudentSubjectController();
        public void InputStudentSubjects()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                StudentSubject();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: StudentListSubjets(); break;
                    case 2: StudentAddSubjects(); break;
                    case 3: StudentUpdateSubjects(); break;
                    case 4: StudentFetchSubjects(); break;
                    case 5: StudentDeleteSubjects(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void StudentSubject()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "STUDENT SUBJECTS MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all subjects");
            Console.WriteLine("2. Add new subject");
            Console.WriteLine("3. Update subjects");
            Console.WriteLine("4. Fetch subjects");
            Console.WriteLine("5. Delete subjects");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void StudentDeleteSubjects()
        {
            Console.Write("Enter Subject ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void StudentFetchSubjects()
        {
            Console.Write("Enter Subject ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var studentExam = this.controller.Get(id);
            if (studentExam != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Student ID: " + studentExam.StudentId);
                Console.WriteLine("Subject ID : " + studentExam.SubjectId);
                Console.WriteLine(new string('-', 40));

            }
        }

        private void StudentUpdateSubjects()
        {
            Console.Write("Enter Subject ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var UpdateSubject = this.controller.Get(id);
            if (UpdateSubject != null)
            {
                Console.Write("Enter exam name: ");
                UpdateSubject.StudentId = int.Parse(Console.ReadLine());
                Console.Write("Enter Exam ID: ");
                UpdateSubject.SubjectId = int.Parse(Console.ReadLine());
     
            }
        }

        private void StudentAddSubjects()
        {
            StudentSubject subject = new StudentSubject();
            Console.Write("Enter  ID: ");
            subject.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter  Student ID: ");
            subject.StudentId = int.Parse(Console.ReadLine());
            Console.Write("Enter Subject ID: ");
            subject.SubjectId = int.Parse(Console.ReadLine());
            Console.Write("Enter Grade ID: ");
            subject.Grade = int.Parse(Console.ReadLine());
            controller.Add(subject);

        }

        private void StudentListSubjets()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "STUDENT SUBJECTS");
            Console.WriteLine(new string('-', 40));
            var studentSubjects = this.controller.GetAll();
            foreach (var studentSubject in studentSubjects)
            {
                Console.WriteLine(value: $"{studentSubject.StudentId} -> {studentSubject.SubjectId} -> {studentSubject.Grade}");
            }
        }
    }
}