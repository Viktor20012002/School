﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplayExams
    {
        private ExamController controller = new ExamController();
        public void InputExams()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                ExamMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: ListExams(); break;
                    case 2: AddExam(); break;
                    case 3: UpdateExams(); break;
                    case 4: FetchExams(); break;
                    case 5: DeleteExams(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void ExamMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "EXAMS MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all exams");
            Console.WriteLine("2. Add new exam");
            Console.WriteLine("3. Update exams");
            Console.WriteLine("4. Fetch exams");
            Console.WriteLine("5. Delete exams");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void DeleteExams()
        {
            Console.Write("Enter Exam ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void FetchExams()
        {
            Console.Write("Enter Exam ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var exam = this.controller.Get(id);
            if (exam != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Exam ID: " + exam.Id);
                Console.WriteLine("Exam Date: " + exam.Date);
                Console.WriteLine(new string('-', 40));
            }
        }

        private void UpdateExams()
        {
            Console.Write("Enter Exam ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var exam = this.controller.Get(id);
            if (exam != null)
            {
                Console.Write("Enter exam Date: ");
                exam.Date = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter exam's subject name: ");
                exam.SubjectId = int.Parse(Console.ReadLine());

            }
        }

        private void AddExam()
        {
            Exam exam = new Exam();
            Console.Write("Enter exam ID: ");
            exam.Id  = int.Parse(Console.ReadLine());
            Console.Write("Enter exam Date: ");
            exam.Date = DateTime.Parse(Console.ReadLine());
            Console.Write("Enter exam's subject name: ");
            exam.SubjectId = int.Parse(Console.ReadLine());
            controller.Add(exam);

        }

        private void ListExams()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "EXAMS");
            Console.WriteLine(new string('-', 40));
            var exams = this.controller.GetAll();
            foreach (var exam in exams)
            {
                Console.WriteLine(value: $"{exam.Id} -> {exam.Date} -> {exam .SubjectId}");
            }
        }
    }
}