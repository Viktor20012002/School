﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplaySubjects
    {
        private SubjectController controller = new SubjectController();
        public void InputSubject()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                SubjectsMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: ListSubjects(); break;
                    case 2: AddSubjects(); break;
                    case 3: UpdateSubjects(); break;
                    case 4: FetchSubjects(); break;
                    case 5: DeleteSubjects(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void SubjectsMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "Subjects MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all Subjects");
            Console.WriteLine("2. Add new Subjects");
            Console.WriteLine("3. Update Subjects");
            Console.WriteLine("4. Fetch Subjects");
            Console.WriteLine("5. Delete Subjects");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void DeleteSubjects()
        {
            Console.Write("Enter Subjects ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void FetchSubjects()
        {
            Console.Write("Enter Subjects ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var Subjects = this.controller.Get(id);
            if (Subjects != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Subjects ID: " + Subjects.Id);
                Console.WriteLine("Subjects Name: " + Subjects.Name);
                Console.WriteLine("Subject Lessons: " + Subjects.Lessons);
                Console.WriteLine(new string('-', 40));
            }
        }

        private void UpdateSubjects()
        {
            Console.Write("Enter Subjects ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var subjects = this.controller.Get(id);
            if (subjects != null)
            {
                Console.Write("Enter Subjects ID: ");
                subjects.Id = int.Parse(Console.ReadLine());
                Console.Write("Enter Subjects name: ");
                subjects.Name = Console.ReadLine();

            }
        }

        private void AddSubjects()
        {
            Subject Subjects = new Subject();
            Console.Write("Enter Subjects ID: ");
            Subjects.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter Subject name: ");
            Subjects.Name = Console.ReadLine();
            Console.Write("Enter Subject Lessons ");
            Subjects.Lessons = int.Parse(Console.ReadLine());
            controller.Add(Subjects);

        }

        private void ListSubjects()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "Subjects");
            Console.WriteLine(new string('-', 40));
            var Subjects = this.controller.GetAll();
            foreach (var Subject in Subjects)
            {
                Console.WriteLine(value: $"{Subject.Id} -> {Subject.Name} -> {Subject.Lessons}");
            }
        }
    }
}