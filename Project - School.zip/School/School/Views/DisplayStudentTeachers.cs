﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplayStudentTeachers
    {
        private StudentsTeachersController controller = new StudentsTeachersController();
        public void InputStudentTeacher()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                StudentTeacherMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: StudentListTeachers(); break;
                    case 2: StudentAddTeachers(); break;
                    case 3: StudentUpdateTeachers(); break;
                    case 4: StudentFetchTeachers(); break;
                    case 5: StudentDeleteTeachers(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void StudentTeacherMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "STUDENT TEACHERS MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all Teachers");
            Console.WriteLine("2. Add new Teachers");
            Console.WriteLine("3. Update Teachers");
            Console.WriteLine("4. Fetch Teachers");
            Console.WriteLine("5. Delete Teachers");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void StudentDeleteTeachers()
        {
            Console.Write("Enter Teacher ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void StudentFetchTeachers()
        {
            Console.Write("Enter Subject ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var studentTeacher = this.controller.Get(id);
            if (studentTeacher != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Student ID: " + studentTeacher.StudentId);
                Console.WriteLine("Teacher ID : " + studentTeacher.TeacherId);
                Console.WriteLine(new string('-', 40));

            }
        }

        private void StudentUpdateTeachers()
        {
            Console.Write("Enter Subject ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var UpdateSubject = this.controller.Get(id);
            if (UpdateSubject != null)
            {
                Console.Write("Enter Student id: ");
                UpdateSubject.StudentId = int.Parse(Console.ReadLine());
                Console.Write("Enter Teacher ID: ");
                UpdateSubject.TeacherId = int.Parse(Console.ReadLine());

            }
        }

        private void StudentAddTeachers()
        {
            StudentsTeachers teacher = new StudentsTeachers();
            
            Console.Write("Enter  Student ID: ");
            teacher.StudentId = int.Parse(Console.ReadLine());
            Console.Write("Enter Subject ID: ");
            teacher.TeacherId = int.Parse(Console.ReadLine());
            controller.Add(teacher);

        }

        private void StudentListTeachers()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "STUDENT SUBJECTS");
            Console.WriteLine(new string('-', 40));
            var studentTeachers = this.controller.GetAll();
            foreach (var studentTeacher in studentTeachers)
            {
                Console.WriteLine(value: $"{studentTeachers.Count} -> {studentTeachers.Capacity} ");
            }
        }
    }
}