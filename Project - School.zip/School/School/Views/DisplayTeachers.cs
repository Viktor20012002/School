﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplayTeachers
    {
        private TeacherController controller = new TeacherController();
        public void InputTeacher()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                TeacherMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: TeacherList(); break;
                    case 2: AddTeacher(); break;
                    case 3: UpdateTeacher(); break;
                    case 4: FetchTeacher(); break;
                    case 5: DeleteTeacher(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void TeacherMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "Teacher MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all Teachers");
            Console.WriteLine("2. Add new Teacher");
            Console.WriteLine("3. Update Teachers");
            Console.WriteLine("4. Fetch Teachers");
            Console.WriteLine("5. Delete Teachers");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void DeleteTeacher()
        {
            Console.Write("Enter Teacher ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void FetchTeacher()
        {
            Console.Write("Enter Teacher ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var teacher = this.controller.Get(id);
            if (teacher != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Teacher ID: " + teacher.Id);
                Console.WriteLine(new string('-', 40));

            }
        }

        private void UpdateTeacher()
        {
            Console.Write("Enter Teacher ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var Teacher = this.controller.Get(id);
            if (Teacher != null)
            {
                Console.Write("Enter Teacher FirstName: ");
                Teacher.FirstName = Console.ReadLine();
               
                Console.Write("Enter Teacher LastName: ");
                Teacher.LastName = Console.ReadLine();
                Console.Write("Enter Student ID: ");
                Teacher.Id = int.Parse(Console.ReadLine());
            }
        }

        private void AddTeacher()
        {
            Teacher NewTeacher = new Teacher();
            Console.Write("Enter Teacher ID: ");
            NewTeacher.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter Teacher Firstname: ");
            NewTeacher.FirstName = Console.ReadLine();
            Console.Write("Enter Teacher LastName: ");
            NewTeacher.LastName = Console.ReadLine();       
            Console.Write("Enter Teacher Address: ");
            NewTeacher.Address = Console.ReadLine();
            Console.Write("Enter student Phone: ");
            NewTeacher.Phone = Console.ReadLine();
            Console.Write("Enter Subject ID: ");
            NewTeacher.SubjectId = int.Parse(Console.ReadLine());
            controller.Add(NewTeacher);
        }

        private void TeacherList()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "STUDENTS");
            Console.WriteLine(new string('-', 40));
            var ListTeacher = this.controller.GetAll();
            foreach (var Teacher in ListTeacher)
            {
                Console.WriteLine(value: $"{Teacher.Id} -> {Teacher.FirstName} -> {Teacher.LastName} -> {Teacher.Address} -> {Teacher.Phone} -> {Teacher.SubjectId} ");
            }
        }
    }
}