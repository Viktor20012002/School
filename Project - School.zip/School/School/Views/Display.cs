﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class Display
    {
        private DisplayExams displayExam = new DisplayExams();
        private DisplayStudents displayStudent = new DisplayStudents();
        private DisplaySubjects displaySubject = new DisplaySubjects();
        private DisplayTeachers displayTeacher = new DisplayTeachers();
        private DisplayStudentExams displayStudentExam = new DisplayStudentExams();
        private DisplayStudentSubject displayStudentSubject = new DisplayStudentSubject();
        private DisplayStudentTeachers displayStudentTeacher = new DisplayStudentTeachers();
        public Display()
        {
            Input();
        }

        private void Input()
        {
            var operation = -1;
            int Close = 8;
            do
            {
                Console.Clear();
                HomeMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: Console.Clear(); displayExam.InputExams(); break;
                    case 2: Console.Clear(); displayStudent.InputStudent(); break;
                    case 3: Console.Clear(); displaySubject.InputSubject(); break;
                    case 4: Console.Clear(); displayTeacher.InputTeacher(); break;
                    case 5: Console.Clear(); displayStudentExam.StudentInputExams(); break;
                    case 6: Console.Clear(); displayStudentSubject.InputStudentSubjects(); break;
                    case 7: Console.Clear(); displayStudentTeacher.InputStudentTeacher(); break;

                    default: break;
                }
            } while (operation != Close);
        }

        private void HomeMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "HOME MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. Exams");
            Console.WriteLine("2. Students");
            Console.WriteLine("3. Subjects");
            Console.WriteLine("4. Teachers");
            Console.WriteLine("5. Student Exams");
            Console.WriteLine("6. Student Subjects");
            Console.WriteLine("7. Student Teachers");
            Console.WriteLine("8. Exit");
        }
    }
}