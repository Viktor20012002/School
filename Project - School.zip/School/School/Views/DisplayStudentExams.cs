﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplayStudentExams
    {
        private StudentExamController controller = new StudentExamController();
        public void StudentInputExams()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                StudentExamMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: StudentListExams(); break;
                    case 2: StudentAddExam(); break;
                    case 3: StudentUpdateExams(); break;
                    case 4: StudentFetchExams(); break;
                    case 5: StudentDeleteExams(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void StudentExamMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "STUDENT EXAMS MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all exams");
            Console.WriteLine("2. Add new exam");
            Console.WriteLine("3. Update exams");
            Console.WriteLine("4. Fetch exams");
            Console.WriteLine("5. Delete exams");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void StudentDeleteExams()
        {
            Console.Write("Enter StudentExam ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void StudentFetchExams()
        {
            Console.Write("Enter StudentExam ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var studentExam = this.controller.Get(id);
            if (studentExam != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Student ID: " + studentExam.StudentId);
                Console.WriteLine("Exam ID : " + studentExam.ExamId);
                Console.WriteLine(new string('-', 40));

            }
        }

        private void StudentUpdateExams()
        {
            Console.Write("Enter Exam ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var exam = this.controller.Get(id);
            if (exam != null)
            {
                Console.Write("Enter exam name: ");
                exam.StudentId = int.Parse(Console.ReadLine());
                Console.Write("Enter Exam ID: ");
                exam.ExamId = int.Parse(Console.ReadLine());
                Console.Write("Enter Grade ID: ");
                exam.Grade = int.Parse(Console.ReadLine());

            }
        }

        private void StudentAddExam()
        {
            StudentExam exam = new StudentExam ();
            Console.Write("Enter Student ID: ");
            exam.StudentId  = int.Parse(Console.ReadLine());
            Console.Write("Enter Exam ID: ");
            exam.ExamId = int.Parse(Console.ReadLine());
            Console.Write("Enter Grade ID: ");
            exam.Grade = int.Parse(Console.ReadLine());
            controller.Add(exam);

        }

        private void StudentListExams()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "EXAMS");
            Console.WriteLine(new string('-', 40));
            var studentExams = this.controller.GetAll();
            foreach (var studentexam in studentExams)
            {
                Console.WriteLine(value: $"{studentexam .StudentId} -> {studentexam.ExamId}");
            }
        }
    }
}