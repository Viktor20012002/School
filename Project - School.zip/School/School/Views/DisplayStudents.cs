﻿using School.Buisness;
using School.Models;
using School.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace School.Views
{
    public class DisplayStudents
    {
        private StudentController controller = new StudentController();
        public void InputStudent()
        {
            var operation = -1;
            int Back = 6;
            do
            {
                StudentMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1: StudentList(); break;
                    case 2: AddStudent(); break;
                    case 3: UpdateStudent(); break;
                    case 4: FetchStudent(); break;
                    case 5: DeleteStudent(); break;
                    default: break;
                }
            } while (operation != Back);
        }

        private void StudentMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 14) + "STUDENT MENU");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all students");
            Console.WriteLine("2. Add new student");
            Console.WriteLine("3. Update students");
            Console.WriteLine("4. Fetch students");
            Console.WriteLine("5. Delete students");
            Console.WriteLine("6. Back to Home Menu");
        }
        private void DeleteStudent()
        {
            Console.Write("Enter Student ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            controller.Delete(id);
            Console.WriteLine("Done");
        }

        private void FetchStudent()
        {
            Console.Write("Enter student ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            var student = this.controller.Get(id);
            if (student != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("Student ID: " + student.Id);       
                Console.WriteLine(new string('-', 40));

            }
        }

        private void UpdateStudent()
        {
            Console.Write("Enter Student ID to update: ");
            int id = int.Parse(Console.ReadLine());
            var student = this.controller.Get(id);
            if (student != null)
            {
                Console.Write("Enter Student name: ");
                student.FirstName = Console.ReadLine();
                Console.Write("Enter Student ID: ");
                student.Id = int.Parse(Console.ReadLine());
            }
        }

        private void AddStudent()
        {
            Student Newstudent = new Student();
            Console.Write("Enter student ID: ");
            Newstudent.Id = int.Parse(Console.ReadLine());
            Console.Write("Enter student Firstname: ");
            Newstudent.FirstName = Console.ReadLine();
            Console.Write("Enter student Middlename: ");
            Newstudent.MiddleName = Console.ReadLine();
            Console.Write("Enter student Lastname: ");
            Newstudent.LastName = Console.ReadLine();
            Console.Write("Enter student Age: ");
            Newstudent.Age = int.Parse(Console.ReadLine());
            Console.Write("Enter student Address: ");
            Newstudent.Address = Console.ReadLine();
            Console.Write("Enter student Phone: ");
            Newstudent.Phone = Console.ReadLine();
            controller.Add(Newstudent);
        }

        private void StudentList()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "STUDENTS");
            Console.WriteLine(new string('-', 40));
            var Liststudent = this.controller.GetAll();
            foreach (var student in Liststudent)
            {
                Console.WriteLine(value: $"{student.Id} -> {student.FirstName} -> {student.MiddleName} -> {student.LastName} ");
            }
        }
    }
}