﻿using School.Data;
using System;
using System.Linq;
using School.Buisness;
using School.Models;
using School.Views;

namespace School
{
    class Program
    {
        static void Main()
        {
            Display display = new Display();
        }
    }
}
