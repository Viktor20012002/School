﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.Data
{
    public static class Connection
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=School;Integrated Security=True";
    }
}
